// echo "# educenter" >> README.md
// git init
// git add README.md
// git commit -m "first commit"
// git remote add origin https://github.com/Evgen097/educenter.git
//     git push -u origin master